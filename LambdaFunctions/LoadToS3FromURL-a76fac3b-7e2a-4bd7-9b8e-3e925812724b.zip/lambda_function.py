import boto3
import botocore.vendored.requests.packages.urllib3 as urllib3
from botocore.vendored import requests


def lambda_handler(event, context):

    url='https://s3-us-west-2.amazonaws.com/css490/input.txt' # put your url here
    bucket = 'reshma-cloud490' #your s3 bucket
    key = 'input.txt' #your desired s3 path or filename

    #s3=boto3.client('s3',aws_access_key_id='AKIAI4TWT7ESIR2XCK5Q',aws_secret_access_key='j/her9oo+ZrQ/r7UYr2Kk5ngOtrFQHCQlmZ5+0Ih')
    s3=boto3.setup_default_session(region_name='us-east-2')
    s3=boto3.client('s3')
    
    #s3.create_bucket(Bucket=bucket )
    http=urllib3.PoolManager()
   # s3.upload_fileobj(http.request('POST', url,preload_c ontent=False), bucket, 'test/file1') 
    
    req_for_image = requests.get(url, stream=True)
    file_object_from_req = req_for_image.raw
    req_data = file_object_from_req.read()

    # Do the actual upload to s3
    
    s3.put_object(Bucket=bucket,Key=key, Body=req_data)
   # s3.upload_fileobj(http.request('POST', url,preload_content=False), bucket, 'test/file1') 
  