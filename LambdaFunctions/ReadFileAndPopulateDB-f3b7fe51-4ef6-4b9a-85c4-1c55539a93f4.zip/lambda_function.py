import boto3
import string

def lambda_handler(event, context):
    s3 = boto3.client('s3')
    dynamodb = boto3.resource('dynamodb', region_name='us-east-2')
    table = dynamodb.Table('PersonDetails')
    bucketName = 'reshma-cloud490'
    response = s3.get_object(Bucket=bucketName, Key='input.txt')
    fileContent = response['Body'].read().decode('utf-8')
   
    myvars = {}
    for line in fileContent.splitlines():
        if (len(line)):
            pairs = line.split(" ") 
            # remove empty strings from the list
            pairs = [x for x in pairs if x != '']
            myvars['lastName'] = pairs[0]
            myvars['firstName'] = pairs[1]
            counter=2
            # loop through rest of data
            while (counter < len(pairs)):
                key,val=pairs[counter].split("=")
                myvars[key]=val
                counter = counter+1
            table.put_item(TableName='PersonDetails', Item=myvars)
            myvars={}
            