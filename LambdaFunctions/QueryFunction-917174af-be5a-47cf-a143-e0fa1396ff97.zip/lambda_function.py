import boto3
import string
import json
from boto3.dynamodb.conditions import Key, Attr
from botocore.exceptions import ClientError

def lambda_handler(event, context):
    s3 = boto3.client('s3')
    #print(event)
    dynamodb = boto3.resource('dynamodb', region_name='us-east-2')
    table = dynamodb.Table('PersonDetails')
    print(len(event['params']['querystring'] ))
    
    try:   
        queryParamsLen = len(event['params']['querystring'])
        #check if input parameters have both first and lastname
        if (queryParamsLen == 2):
            #return (event['params']['querystring'])
            if ((event['params']['querystring']['firstName'])=='') :
                #return('hereee')
                response = table.query(
                KeyConditionExpression=Key('lastName').eq(event['params']['querystring']['lastName'])
                )
                if response['Items'] == []:
                    return ('No records found for search!')
           
                else:
                    return(response['Items'])
            elif ((event['params']['querystring']['lastName'])=='') :
                response = table.query(
                KeyConditionExpression=Key('firstName').eq(event['params']['querystring']['firstName']),
                IndexName = 'firstName-lastName-index'
                )
                if response['Items'] == []:
                    return ('No records found for search!')
           
                else:
                    return(response['Items'])
       
            #check if records returned
        if (queryParamsLen == 2):
            print('inside len==2')
           
            response = table.query(
                KeyConditionExpression=Key('firstName').eq(event['params']['querystring']['firstName']) & Key('lastName').eq(event['params']['querystring']['lastName'])
                )
            for i in response['Items']:
                print (i)
            return(response['Items'])

        
    except ClientError as e:
         
        if e.response['Error']['Code'] == 'ValidationException':
             print('*****')
             print( e.response )
        else:
             return {'error>>':'No records'}
        